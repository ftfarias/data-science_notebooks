# neo4j-jupyter

A [series of Jupyter notebooks](http://nicolewhite.github.io/neo4j-jupyter/main.html) to help data scientists get started with Python and Neo4j.
